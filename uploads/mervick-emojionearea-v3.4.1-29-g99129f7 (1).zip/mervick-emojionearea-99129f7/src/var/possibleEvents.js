define(function() {
    return {};
});